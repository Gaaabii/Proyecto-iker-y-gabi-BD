/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOAuthors;
import com.mycompany.models.authors;
import com.mycompany.models.clientes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author balea
 */
public class DAOAuthorsImpl extends Database implements DAOAuthors {

    @Override
    public void registar(authors authors) throws Exception {
        try{
            this.Conectar();
            PreparedStatement st=this.conexion.prepareStatement("INSERT INTO authors(Authors_name,Authors_Country,Authors_Birthday) VALUES(?,?,?);");
            st.setString(1, authors.getAuthor_name());
            st.setString(2,authors.getAuthors_Country());
            st.setString(3,authors.getAuthor_Birthday());
            st.executeUpdate();
        }catch(Exception e){
            throw e;
        }finally{
        this.Cerrar();
    }
    }

    @Override
    public void eliminar(int id_cliente) throws Exception {
           try{
            this.Conectar();
            PreparedStatement st=this.conexion.prepareStatement("DELETE FROM authors WHERE Authors_id=?;");
            st.setInt(1,id_cliente);
            st.executeUpdate();
        }catch(Exception e){
            throw e;
        }finally{
        this.Cerrar();
    }
    }

    /**
     *
     * @return
     * @throws Exception
     */
    @Override
public List<authors> listar(String id) throws Exception {
    List<authors> lista = new ArrayList<>();
    try {
        this.Conectar();
        String query = id.isEmpty() ? "SELECT * FROM authors" : "SELECT * FROM authors WHERE Authors_id = ?";
        PreparedStatement st = this.conexion.prepareStatement(query);

        if (!id.isEmpty()) {
            st.setInt(1, Integer.parseInt(id));
        }

        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            authors r1 = new authors();
            r1.setAuthorsid(rs.getInt("Authors_id"));
            r1.setAuthor_name(rs.getString("Authors_name"));
            r1.setAuthors_Country(rs.getString("Authors_country"));
            r1.setAuthor_Birthday(rs.getString("Authors_birthday"));
            lista.add(r1);
        }
        rs.close();
        st.close();
    } catch (Exception e) {
        System.out.println("Error en listar: " + e.getMessage());
        e.printStackTrace(); // Imprimir la pila de excepciones para depuración
    } finally {
        this.Cerrar();
    }
    return lista;
}

}


    

