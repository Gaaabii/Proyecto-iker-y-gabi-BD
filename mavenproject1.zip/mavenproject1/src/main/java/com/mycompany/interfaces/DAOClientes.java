/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfaces;

import com.mycompany.models.clientes;
import java.util.List;

/**
 *
 * @author balea
 */
public interface DAOClientes {
    public void registar(clientes cliente) throws Exception;
    public void eliminar(int id_cliente) throws Exception;
    public List<clientes> listar(String nombre) throws Exception;
    
}
