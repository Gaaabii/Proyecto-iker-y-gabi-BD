/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.models;
import java.time.LocalDate;
/**
 *
 * @author balea
 */
public class loans {
    private int Loans_id;
    private int Loans_Members_id;
    private int Loans_Books_id;
    private String Loans_end_date;
    private String Loans_beegin_date;

    public int getLoans_id() {
        return Loans_id;
    }

    public void setLoans_id(int Loans_id) {
        this.Loans_id = Loans_id;
    }

    public int getLoans_Members_id() {
        return Loans_Members_id;
    }

    public void setLoans_Members_id(int loans_Members_id) {
        this.Loans_Members_id = loans_Members_id;
    }

    public int getLoans_Books_id() {
        return Loans_Books_id;
    }

    public void setLoans_Books_id(int loans_Books_id) {
        this.Loans_Books_id = loans_Books_id;
    }

    public String getLoans_end_date() {
        return Loans_end_date;
    }

    public void setLoans_end_date(String loans_end_date) {
        this.Loans_end_date = loans_end_date;
    }

    public String getLoans_beegin_date() {
        return Loans_beegin_date;
    }

    public void setLoans_beegin_date(String loans_beegin_date) {
        this.Loans_beegin_date = loans_beegin_date;
    }
    


    
}
