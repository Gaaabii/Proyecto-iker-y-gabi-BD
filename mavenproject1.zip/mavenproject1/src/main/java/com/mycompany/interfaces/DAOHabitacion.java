/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfaces;
import com.mycompany.models.habitacion;
import java.util.List;

/**
 *
 * @author balea
 */
public interface DAOHabitacion {
    public void registar(habitacion h1) throws Exception;
    public void eliminar(habitacion h1) throws Exception;
    public List<habitacion> listar(String nombre) throws Exception;
    
}