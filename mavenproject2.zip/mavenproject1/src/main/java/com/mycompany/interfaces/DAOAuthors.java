/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfaces;

import com.mycompany.models.authors;
import java.util.List;

/**
 *
 * @author balea
 */
public interface DAOAuthors {
    public void registar(authors Authors) throws Exception;
    public void eliminar(int Author_Id) throws Exception;
    public List<authors> listar(String id) throws Exception;
    
}
