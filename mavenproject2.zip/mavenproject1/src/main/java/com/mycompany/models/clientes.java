/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.models;

/**
 *
 * @author balea
 */
public class clientes {
    private int Members_id;
    private String Members_name;
    private String Members_age;
    private String Members_register_date;


    public void setId_cliente(int Members_id) {
        this.Members_id=Members_id;
    }

    public void setNombre(String Members_name) {
        this.Members_name = Members_name;
    }

    public void setMembersage(String Members_age) {
        this.Members_age = Members_age;
    }

    public void setMembersregisterdate(String Members_register_date) {
        this.Members_register_date = Members_register_date;
    }



    public int getMembers_id() {
        return Members_id;
    }

    public String getMembers_name() {
        return Members_name;
    }

    public String getMembers_age() {
        return Members_age;
    }

    public String getMembers_register_date() {
        return Members_register_date;
    }


}
