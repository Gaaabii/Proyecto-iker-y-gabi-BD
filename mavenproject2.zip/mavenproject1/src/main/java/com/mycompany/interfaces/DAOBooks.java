/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfaces;
import com.mycompany.models.books;
import java.util.List;

/**
 *
 * @author balea
 */
public interface DAOBooks {
    public void registar(books h1) throws Exception;
    public void eliminar(int Book_id) throws Exception;
    public List<books> listar(String nombre) throws Exception;
    
}