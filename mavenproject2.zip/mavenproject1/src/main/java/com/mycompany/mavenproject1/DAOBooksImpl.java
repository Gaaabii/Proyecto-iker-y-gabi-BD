/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;
import com.mycompany.db.Database;




import com.mycompany.models.books;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOBooks;

/**
 *
 * @author balea
 */
public class DAOBooksImpl extends Database implements DAOBooks {
        @Override
        public List<books> listar(String id) throws Exception {
               List<books> lista=null;
       try{
            this.Conectar();
            String Query=id.isEmpty()?"SELECT * FROM books":"SELECT * FROM books WHERE Book_id = "+id+";";
            PreparedStatement st=this.conexion.prepareStatement(Query); 
            lista=new ArrayList();
            ResultSet rs=st.executeQuery();
            while(rs.next()){
                books r1=new books();
                r1.setBokkid(rs.getInt("Book_id"));
                r1.setBooktitle(rs.getString("Book_title"));
                r1.setBookeditorial(rs.getString("Book_editorial"));
                r1.setBookstate(rs.getString("Book_state"));
                r1.setbookidauthor(rs.getInt("Book_id_author"));

                lista.add(r1);
                
            }
            rs.close();
            st.close();
       }catch(Exception e){
           
       }finally{
           this.Cerrar();
       }
       return lista;
    }

    @Override
    public void registar(books books) throws Exception {
           try{
            this.Conectar();
            PreparedStatement st=this.conexion.prepareStatement("INSERT INTO books(Book_title,Book_editorial,Book_id_author) VALUES(?,?,?);");
            st.setString(1, books.getBooktitle());
            st.setString(2,books.getBookeditorial());
            st.setInt(3,books.getBookidauthor());
            st.executeUpdate();
        }catch(Exception e){
            throw e;
        }finally{
        this.Cerrar();
    }
    }

    @Override
    public void eliminar(int Book_id) throws Exception {
                   try{
            this.Conectar();
            PreparedStatement st=this.conexion.prepareStatement("DELETE FROM books WHERE Book_id=?;");
            st.setInt(1,Book_id);
            st.executeUpdate();
        }catch(Exception e){
            throw e;
        }finally{
        this.Cerrar();
    }
    }

}
