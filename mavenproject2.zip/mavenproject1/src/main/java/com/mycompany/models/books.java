/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.models;

/**
 *
 * @author balea
 */
public class books {
    private int Book_id;
    private String Book_title;
    private String Book_editorial;
    private String Book_state;
    private int Book_id_author;

    public String getBookstate(){
        return Book_state;
    }
    public void setBookstate(String Bookstate){
        this.Book_state=Bookstate;
    }
    public void setBokkid(int Book_id) {
        this.Book_id = Book_id;
    }
      public int getBookidauthor(){
        return Book_id_author;
    }
    public void setbookidauthor(int bookidauthor){
        this.Book_id_author=bookidauthor;
    }

    public void setBooktitle(String Book_title) {
        this.Book_title = Book_title;
    }

    public void setBookeditorial(String Book_editorial) {
        this.Book_editorial = Book_editorial;
    }


    public int getBookid() {
        return Book_id;
    }

    public String getBooktitle() {
        return Book_title;
    }

    public String getBookeditorial() {
        return Book_editorial;
    }


}
