package com.mycompany.mavenproject1;

import com.mycompany.db.Database;
import com.mycompany.models.loans;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOLoans;

public class DAOLoansImpl extends Database implements DAOLoans {
    @Override
    public void registar(loans r1) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO loans(loans_Members_id, loans_Books_id, loans_beegin_date, loans_end_date) VALUES(?, ?, ?, ?);");
            st.setInt(1, r1.getLoans_Members_id());
            st.setInt(2, r1.getLoans_Books_id());
            st.setString(3, r1.getLoans_beegin_date());
            st.setString(4, r1.getLoans_end_date());
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(int id_reserva) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM loans WHERE loans_id = ?;");
            st.setInt(1, id_reserva);
            st.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<loans> listar(String id) throws Exception {
        List<loans> lista = null;
        try {
            this.Conectar();
            String Query = id.isEmpty() ? "SELECT * FROM loans" : "SELECT * FROM loans WHERE loans_id = " + id + "";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            lista = new ArrayList<>();
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                loans r1 = new loans();
                r1.setLoans_id(rs.getInt("loans_id"));
                r1.setLoans_Members_id(rs.getInt("loans_Members_id"));
                r1.setLoans_Books_id(rs.getInt("loans_Books_id"));
                r1.setLoans_beegin_date(rs.getString("loans_beegin_date"));
                r1.setLoans_end_date(rs.getString("loans_end_date"));
                lista.add(r1);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }
}
