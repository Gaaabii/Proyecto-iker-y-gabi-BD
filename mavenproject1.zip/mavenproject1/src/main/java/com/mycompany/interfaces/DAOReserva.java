/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfaces;

import com.mycompany.models.reserva;
import java.util.List;

/**
 *
 * @author balea
 */
public interface DAOReserva {
    public void registar(reserva r1) throws Exception;
    public void eliminar(int id_reserva) throws Exception;
    public List<reserva> listar(String id) throws Exception;
    
}