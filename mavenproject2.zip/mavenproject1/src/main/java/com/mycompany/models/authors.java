/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.models;

/**
 *
 * @author balea
 */
public class authors {
    private int Authors_id;
    private String Author_name;
    private String Authors_Country;
    private String Author_Birthday;


    public void setAuthorsid(int Authors_id) {
        this.Authors_id=Authors_id;
    }

    public void setAuthor_name(String Author_name) {
        this.Author_name = Author_name;
    }

    public void setAuthors_Country(String Authors_Country) {
        this.Authors_Country = Authors_Country;
    }

    public void setAuthor_Birthday(String Author_Birthday) {
        this.Author_Birthday = Author_Birthday;
    }



    public int getAuthors_id() {
        return Authors_id;
    }

    public String getAuthor_name() {
        return Author_name;
    }

    public String getAuthors_Country() {
        return Authors_Country;
    }

    public String getAuthor_Birthday() {
        return Author_Birthday;
    }


}
