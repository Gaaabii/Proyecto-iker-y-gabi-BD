/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfaces;

import com.mycompany.models.loans;
import java.util.List;

/**
 *
 * @author balea
 */
public interface DAOLoans {
    public void registar(loans r1) throws Exception;
    public void eliminar(int id_reserva) throws Exception;
    public List<loans> listar(String id) throws Exception;
    
}