/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOClientes;
import com.mycompany.models.clientes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author balea
 */
public class DAOClientesImpl extends Database implements DAOClientes {

    @Override
    public void registar(clientes cliente) throws Exception {
        try{
            this.Conectar();
            PreparedStatement st=this.conexion.prepareStatement("INSERT INTO members(Members_name,Members_age,Members_register_date) VALUES(?,?,?);");
            st.setString(1, cliente.getMembers_name());
            st.setString(2,cliente.getMembers_age());
            st.setString(3,cliente.getMembers_register_date());
            st.executeUpdate();
        }catch(Exception e){
            throw e;
        }finally{
        this.Cerrar();
    }
    }

    @Override
    public void eliminar(int id_cliente) throws Exception {
           try{
            this.Conectar();
            PreparedStatement st=this.conexion.prepareStatement("DELETE FROM members WHERE Members_id=?;");
            st.setInt(1,id_cliente);
            st.executeUpdate();
        }catch(Exception e){
            throw e;
        }finally{
        this.Cerrar();
    }
    }

    /**
     *
     * @return
     * @throws Exception
     */
    @Override
    public List<clientes> listar(String id) throws Exception {
         List<clientes> lista=null;
       try{
          this.Conectar();
          String Query=id.isEmpty()?"SELECT * FROM members":"SELECT * FROM members WHERE Members_id = "+id+";";
              PreparedStatement st=this.conexion.prepareStatement(Query); 
            
            lista=new ArrayList();
            ResultSet rs=st.executeQuery();
            while(rs.next()){
                clientes r1=new clientes();
                r1.setId_cliente(rs.getInt("Members_id"));
                r1.setNombre(rs.getString("Members_name"));
                r1.setMembersage(rs.getString("Members_age"));
                r1.setMembersregisterdate(rs.getString("Members_register_date"));
     
                lista.add(r1);
                
            }
            rs.close();
            st.close();
       }catch(Exception e){
           
       }finally{
           this.Cerrar();
       }
       return lista;    
    }
}


    

